
import 'package:flutter/material.dart';

void main() => runApp(VirtuGeneApp());

class VirtuGeneApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'VirtuGene',
      theme: ThemeData(primarySwatch: Colors.green),
      home: HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('VirtuGene')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text('Welcome to VirtuGene!', style: TextStyle(fontSize: 20)),
            SizedBox(height: 20),
            ElevatedButton(onPressed: () {}, child: Text('Simulate Trait')),
            ElevatedButton(onPressed: () {}, child: Text('Search Database')),
          ],
        ),
      ),
    );
  }
}
